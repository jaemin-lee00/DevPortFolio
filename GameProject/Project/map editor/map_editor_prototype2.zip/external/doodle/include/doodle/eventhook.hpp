#pragma once
/*--------------------------------------------------------------*
  Copyright (C) 2019 Rudy Castan

  This file is distributed WITHOUT ANY WARRANTY. See the file
  `License.md' for details.
*--------------------------------------------------------------*/
#pragma once

#ifndef DOODLE_API
#    define EVENT_HOOK extern "C" __declspec(dllexport)
#endif
